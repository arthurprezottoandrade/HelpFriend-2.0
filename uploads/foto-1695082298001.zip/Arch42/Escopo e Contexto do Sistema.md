# 3. Escopo e Contexto do Sistema


Este capítulo descreve o ambiente e o contexto do SmartBins : Quem usa o sistema e de qual outro sistema o SmartBins depende.


**3.1. Contexto empresarial**

![Contexto Empresarial](contexto_empresarial.png)

- **Lixeira**
    A lixeira possui sensores de laser e peso, que permitem a medição precisa da quantidade de resíduos no interior da lixeira. Ela se conecta ao sistema SmartBins para enviar dados em tempo real.
- **Google Maps**
    O Google Maps, integrado ao sistema SmartBins, recebe o endereço da lixeira e a localização atual do caminhão. Em seguida, calcula automaticamente a rota mais eficiente para a coleta de lixo e a envia de volta para o sistema.
- **Gerente Central**
    O Gerente da Central é o ponto focal do sistema SmartBins. Ele coordena a equipe, garantindo uma comunicação eficaz entre o Atendente Central e o Motorista. Além disso, é responsável pelo cadastro, edição e exclusão de dados desses membros.
- **Atendente Central**
    O Atendente da Central, como peça fundamental, recebe notificações das lixeiras pelo sistema SmartBins e monitora o estado das lixeiras e dos caminhões de coleta.
- **Motorista**
    O motorista recebe a rota da coleta do sistema SmartBins e conduz o caminhão até a lixeira. Ele também recebe notificações do atendente central para coordenar a coleta de lixo de forma eficiente.
- **Caminhão**
    O caminhão de coleta, equipado com um sistema de GPS, é operado pelo motorista. Ele utiliza essa tecnologia para navegar com precisão até o endereço da lixeira. 

**3.2. Contexto Técnico**

![Contexto Técnico](contexto_tecnico.png)

SmartBins é dividido em 2 componentes principais:

**Back-end (SmartBins::API)**

O sistema será hospedado nos servidores da AWS (Amazon Web Services).

Uma das integrações críticas do sistema é com o serviço web do Google Maps. Essa integração permite que o sistema SmartBins calcule rotas otimizadas para os caminhões de coleta de lixo. Ele recebe solicitações de navegação e fornece informações precisas de direção aos motoristas, garantindo que eles alcancem as lixeiras da forma mais eficaz possível.

Além disso, o sistema SmartBins está profundamente integrado com os sensores das lixeiras, que enviam notificações constantes sobre o estado das mesmas. Esses sensores detectam informações cruciais, como o nível de enchimento das lixeiras, a presença de obstruções ou problemas técnicos. Essas notificações são essenciais para manter um monitoramento em tempo real das condições das lixeiras, permitindo uma resposta rápida a quaisquer problemas.

**Front-end (Web e Mobile)**

O frontend é implementado com dois componentes diferentes, como Web e Mobile. O Atentende Central utilizará a plataforma web para exucutar suas atividades e o motorista acessará o sistema através do celular. Os dois componentes contarão com a aplicação SmartBins.

# 4. Estratégia de Solução

O sistema SmartBins foi construído para melhorar a eficiência da coleta de lixo, introduzindo tecnologias para facilitar o processo. Ele será desenvolvido com o estilo arquitetural de microservices e Representational State Transfer (REST).

A arquitetura de microservices, na qual a aplicação é dividida em pequenos serviços independentes com responsabilidades específicas, será utilizada para garantir que, se ocorrer algum problema em um serviço, outros serviços ainda permanecerão funcionais. O sistema estará hospedado em um servidor de forma segura. No entanto, é importante observar que, embora o sistema seja seguro, os sensores da lixeira, devido ao ambiente externo e às condições variáveis, podem estar sujeitos a problemas potenciais.

No estilo REST, a implementação do cliente e do servidor pode ser feita de forma independente, sem que cada um conheça o outro. Isso significa que o código do lado do cliente pode ser alterado a qualquer momento, sem afetar a operação do servidor, e o contrário também é válido.

![Contexto Técnico](diagrama_solucao.png)

O BFF Mobile estará se comunicando apenas com o Microservice Sistema, pois o Motorista não terá acesso aos sensores e apenas deve receber sua rota de coleta de lixo. 