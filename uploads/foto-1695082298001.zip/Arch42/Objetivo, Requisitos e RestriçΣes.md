# 1. Introdução e objetivos

O Smartbins é um sistema focado em melhor eficiência na coleta de lixo, utilizando sensores nas lixeiras e sensores nos caminhões de coleta para otimizar a coleta ao maximo

-   Melhores rotas para os caminhões de coleta;

-   Coletas realizadas somente com a lixeira cheia, melhorando a eficiência da rota


**1.1 Visão geral dos requisitos**


O SmartBins é um sistema para otimizar coletas, facilitando a vida do trabalhador, otimizando tempo.

Principais caractreristicas:
- O sistema deve apresentar uma pagina web para monitorar o estado dos sensores das lixeiras em tempo real
- O sistema deve fornecer, via API do Google Maps, a melhor rota para a coleta do lixo
- Os sensores da lixeira devem notificar a central de gerenciamento de resíduos, via sistema, que o lixo foi coletado

O gerente da central é o unico capaz de manter o cadastro dos funcionarios incluindo o atendente e motorista.

Link para acessar a documentação dos requisitos: https://pucpredu-my.sharepoint.com/:x:/g/personal/joao_wozniack_pucpr_edu_br/EZVQh4OcThlMkEb5cNlsiR8B2r7Crfkx8Fhcf62oiYmMgQ?e=TFScrX

**Requisitos**

| ID | Requisito |
| - | ----------|
|RF1 | O sistema deve apresentar uma tela para cadastro do usuário|
|RF2 | O sistema deve apresentar uma tela para login do usuário    |
|RF3 | O sistema deve apresentar uma tela para editar os dados do usuário |
|RF4 | O sistema deve apresentar uma tela com todas as funcionalidades do sistema|
|RF5 | O sistema deve apresentar uma página para monitorar o estado dos sensores da lixeira em tempo real|
|RF6 |	O sistema deve apresentar uma página para monitorar o estado das lixeiras em tempo real|
|RF7 | O sistema deve fornecer, via API do Google Maps, a melhor rota para a coleta do lixo|
|RF8 | Os sensores da lixeira devem comunicar a central de gerenciamento de resíduos, via sistema, sobre o estado atual da lixeira.
|RF9 | Os sensores da lixeira devem notificar a central de gerenciamento de resíduos, via sistema, que o lixo foi coletado |
|RF10 | O sensor do caminhão deve transmitir sua localização em tempo real, via sistema, à central de gerenciamento de resíduos.|
|RF11 |	O sistema deve apresentar uma página para monitorar os caminhões de lixo em tempo real|
|RF12 |O sistema deve fornecer um relatório com as lixeiras mais utilizadas por área|
|RF13 | O sistema deve utilizar a API do Google Maps para oferecer a rota mais eficiente até o aterro sanitário, após a conclusão da coleta do lixo.|
|RF14 | O sistema deve efetuar uma verificação para identificar se lixeiras próximas da localização do caminhão necessitam da coleta de lixo.|
|RF15 | O sistema deve apresentar uma tela com um chat entre a central de gerenciamento de resíduos e o caminhão de lixo|


**1.2 Metas de qualidade**


| Nº | Qualidade | Motivação|
| --  | ------- | ---------|
|1| Eficiência | Coletar dados das rotas dos caminhões deve ser uma tarefa| fácil, para melhorar a otimização da rota
|2| Atratividade | Os dados das rotas deve ser mostrandos em um Dashboard| facil de entender
|3|Testabilidade| A arquitetura deve permitir testes faceis de todas as principais funcionalidades do sistema |


**1.3 Stakeholders**


Visão geral explícita das partes interessadas do sistema, ou seja, todas as pessoas interessadas no projeto:

-   Devem conhecer o problema a ser resolvido

-   Devem conhecer as principais funcionalidades do sistema


Tabela com nomes de papéis, nomes de pessoas e suas expectativas em relação
à arquitetura e sua documentação.

| Nome  | Expectativas |
| ----- | -----------|
| Desenvolvedores |Desenvolver o sistema|
| Engenheiro de software | Criar a documentação e monitorar o andamento do projeto |
| Motorista | Receber a melhor rota ate a coleta |
| Atendente | Monitorar os camimhões e gerar relatorios |
| Gerente da central | Manter o cadastro dos funcionarios |
| Prefeitura | Informações sobre a coleta de lixo|




# 2. Restrições de Arquitetura {#section-architecture-constraints}


**2.1 Restrições Técnicas**


| | Limitação | Antecedentes e/ou motivação |
|-| --------- | ----------------------------|
|RT1| Plataforma de Hardware | O sistema deve ser compatível com uma variedade de dispositivos, como smartphones, tablets e computadores, considerando suas capacidades de processamento e recursos.|
|RT2| Conectividade | O sistema deve ser capaz de funcionar de forma eficaz tanto em ambientes com conectividade de alta velocidade como em locais com conexões mais lentas ou intermitentes. 
|RT3| Escalabilidade | O sistema deve ser projetado para acomodar o aumento de dados e usuários ao longo do tempo sem comprometer o desempenho. |
|RT4| Segurança de Dados | As informações sensíveis, como dados de localização e informações de coleta, devem ser protegidas com criptografia robusta e práticas de segurança para evitar acessos não autorizados. |
|RT5| Integração | O sistema deve ser capaz de se integrar com sistemas de GPS, sensores de lixeira e outros dispositivos, garantindo uma troca de informações eficiente. |
|RT6| Compatibilidade de Navegadores | O sistema deve ser compatível com uma variedade de navegadores populares, incluindo Chrome, Firefox, Safari e Edge, garantindo uma experiência consistente para os usuários. |
|RT7| Backup e Recuperação de Dados | Deve haver mecanismos de backup e planos de recuperação de dados para evitar perda de informações valiosas em caso de falhas no sistema. |


**2.2 Restrições Organizacionais**

| | Limitação | Antecedentes e/ou motivação |
|-| --------- | ----------------------------|
|RO1| Orçamento | O sistema deve ser desenvolvido dentro dos limites financeiros definidos pela organização, considerando custos de desenvolvimento, manutenção e operação.|
|RO2| Recursos Humanos | Restrições relacionadas à disponibilidade de pessoal qualificado para desenvolvimento, implementação e suporte contínuo do sistema. |
|RO3| Prazos | O sistema deve ser projetado e implementado dentro de um cronograma específico, levando em consideração datas de lançamento, marcos importantes e necessidades operacionais. |
|RO4| Políticas Internas | O sistema deve cumprir as políticas e diretrizes da organização, incluindo políticas de segurança da informação, privacidade de dados e outros padrões internos. |
|RO5| Disponibilidade de Dados | Restrições sobre os tipos de dados que podem ser coletados e usados no sistema, de acordo com as políticas e regulamentações da organização. |
|RO6| Acordos de Parceria | Se houver parcerias ou colaborações com outras entidades, o sistema deve cumprir acordos estabelecidos e considerar as necessidades das partes envolvidas. |
|RO7| Conformidade Legal | O sistema deve aderir a todas as leis e regulamentações pertinentes ao gerenciamento de resíduos, proteção de dados, segurança e outros aspectos relacionados. | 

 **2.3 Convenções**

| | Convenções | Antecedentes e/ou motivação |
|-| --------- | ----------------------------|
|C1| Documentação de arquitetura | Estrutura baseada no inglês arc-42-Template na versão 6.5. |
|C2| Convenções de codificação | O projeto utiliza a linguagem de marcação HTML, linguagem de estilo CSS e linguagem de Programação Javascript e Node.js.
|C3| Linguagem | Português. O projeto correspondente têm como público alvo nacional, localizado na cidade de Curitiba. |
|C4| Convenções de nomenclatura | .JFX (Javascript) |